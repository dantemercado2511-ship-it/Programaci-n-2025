import numpy as np

x = float(input('Ingrese x: '))
y = float(input('Ingrese y: '))


print(f'x^y={x**y}')
print(f'Log_2(x)={np.log2(y)}')
